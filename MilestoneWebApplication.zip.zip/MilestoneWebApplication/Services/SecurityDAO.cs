﻿using MilestoneWebApplication.Models;
using MySqlConnector;
using System.Data.SqlClient;

namespace RegisterAndLoginApp.Services
{
    public class SecurityDAO
    {

       // MySQL connection string using MAMP: (Caleb)
       //String connectionString = "datasource=172.24.108.38;port=8889;username=root;password=root;database=milestoneWebApp";
       // MySql connection string using MAMP: (Logan)
        String connectionString = "datasource=172.25.7.72;port=3306;username=root;password=root;database=minesweeper_login";




        public bool AddNewUser(User user)
        {
            bool success = false;
            string sqlStatement = "INSERT INTO `users` (`Id`, `firstName`, `lastName`, `sex`, `age`, `state`, `email`, `username`, `password`) VALUES (NULL, @firstName, @lastName, @sex, @age, @state, @email, @username, @password)";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@firstName", user.firstName);
                command.Parameters.AddWithValue("@lastName", user.lastName);
                command.Parameters.AddWithValue("@sex", user.sex);
                command.Parameters.AddWithValue("@age", user.age);
                command.Parameters.AddWithValue("@state", user.state);
                command.Parameters.AddWithValue("@email", user.email);
                command.Parameters.AddWithValue("@username", user.username);
                command.Parameters.AddWithValue("@password", user.password);


                try
                {
                    connection.Open();
                    int rows = command.ExecuteNonQuery();
                    connection.Close();

                    if(rows == 1)
                    {
                        success = true;
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                return success;

            }

        }

        public bool FindUserByNameAndPassword(User user)
        {
            bool success = false;

            string sqlStatement = "SELECT * FROM USERS WHERE USERNAME = @username and PASSWORD = @password";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@username", user.username);
                command.Parameters.AddWithValue("@password", user.password);

                try
                {
                    connection.Open();
                    MySqlDataReader reader= command.ExecuteReader();
                    if(reader.HasRows)
                    {
                        success = true;
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
            }

                return success;
        }


    }
}
